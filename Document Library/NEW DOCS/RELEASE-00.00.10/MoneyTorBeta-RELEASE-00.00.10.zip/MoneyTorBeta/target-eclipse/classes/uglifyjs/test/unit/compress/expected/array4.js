(function(){function a(){}(function(){return new a(1,2,3)})()})()
