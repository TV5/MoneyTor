new (A, B)
new (A || B)
new (X ? A : B)