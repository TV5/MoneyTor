(function() {
    var x = function fun(a, fun, b) {
        return fun;
    };
}());
